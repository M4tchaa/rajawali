<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom shadow-sm">
    <div class="container-fluid d-flex justify-content-between align-items-center px-4">
        <span class="navbar-brand mb-0 h5"></span>

        <div class="d-flex align-items-center py-2 pr-4">
            <!-- Icon Notifikasi -->
            <a href="#" class="text-dark position-relative" style="margin-right: 20px;">
                <i class="bi bi-bell" style="font-size: 1.5rem;"></i>
                <!-- Badge Notif (opsional) -->
                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    3
                    <span class="visually-hidden">unread messages</span>
                </span>
            </a>
        </div>
    </div>
</nav>
