        <!-- Bootstrap n Jquery JS -->
        <script src="public/js/jquery.min.js"></script>
        <script src="public/js/bootstrap.min.js"></script>

        <!-- Other Script -->
        <!-- <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script> -->
        
        <!-- Custom Script -->
        <script src="public/js/scripts.js?v=<?= filemtime(FCPATH . 'public/js/scripts.js') ?>"></script>
        <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
        
        <!-- Core plugin JavaScript-->
        <!-- <script src="vendor/jquery-easing/jquery.easing.min.js"></script> -->
        
        <!-- Custom scripts for all pages-->
        <!-- <script src="assets/js/sb-admin-2.min.js"></script> -->
    </body>
</html>