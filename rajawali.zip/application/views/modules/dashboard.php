<div class="container mt-4">
    <h2>Dashboard</h2>
    <div class="row mt-3">
        <div class="col-md-4">
            <div class="card border-left-primary shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Total Users</h5>
                    <p class="card-text display-4">123</p>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card border-left-success shadow-sm">
                <div class="card-body">
                    <h5 class="card-title">Active Sessions</h5>
                    <p class="card-text display-4">15</p>
                </div>
            </div>
        </div>
    </div>
</div>
